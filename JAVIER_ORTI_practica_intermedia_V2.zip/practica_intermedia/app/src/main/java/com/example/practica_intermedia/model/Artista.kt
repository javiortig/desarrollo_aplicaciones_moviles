package com.example.practica_intermedia.model

data class Artista (var nombre: String, val imagen: String)
