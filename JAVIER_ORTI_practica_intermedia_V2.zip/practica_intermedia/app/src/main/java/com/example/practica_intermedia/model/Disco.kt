package com.example.practica_intermedia.model

data class Disco(var nombre: String, var grupo: String, var discografica: String, var anio: Int, val imagen: String) {

}